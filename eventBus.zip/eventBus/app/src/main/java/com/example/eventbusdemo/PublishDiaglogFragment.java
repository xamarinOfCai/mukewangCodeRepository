package com.example.eventbusdemo;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class PublishDiaglogFragment extends DialogFragment {


    public interface OnItemListener{
        public void onSuccess();

        public void onFailure();
    }

    private OnItemListener mListener;

    public PublishDiaglogFragment(OnItemListener listener){
        this.mListener = listener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        final AlertDialog.Builder builder =new AlertDialog.Builder(getActivity());
        builder.setTitle("Publish");
        final String[] items = {"Success","Failure"};
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case 0://success
                        if (mListener != null) {
                            mListener.onSuccess();
                        }
                        break;

                    case 1://fail
                        if (mListener != null) {
                            mListener.onFailure();
                        }
                        break;
                    default:
                        break;
                }
            }
        });
        return builder.create();
    }
}
